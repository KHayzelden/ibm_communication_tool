# ibm-communication-tool Bookmark/History page


###File 
index-xxx pages to establish with mobile version.
book-mobile-xxx: bookmark page on mobile version (simple and full)
history-mobile: history page on mobile version
book-tablet: bookmark page on tablet/web version


###Version history

1. 29 Jan 2019: Add the web page prototype including simple jquery for adding and deleting
2. 05 Feb 2019: Add the mobile version of the bookmark page
3. 17 Feb 2019: Add simple version and the tab manu to switch content
4. 03 Mar 2019: Modify history page into mobile version


###Library

1. sweetalert
2. jQuery.mmenu
3. MUDI
4. Bootrap



